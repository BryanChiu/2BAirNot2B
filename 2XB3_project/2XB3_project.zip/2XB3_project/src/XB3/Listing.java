package XB3;

import java.math.BigDecimal;
import java.util.Map;

/**
 * @author Michael Yohannes
 */

public class Listing implements Comparable<Listing> {

	private int id;
	private boolean superHost;
	private String neighborhood;
	private String zipcode;
	private String propType;
	private Double accommodates;
	private Double bathrooms;
	private Double bedrooms;
	private Double dayPrice;
	private Double reviewRating;
	private Double avail365;
//	private Double revenue;
	private BigDecimal revenue;
	private String treeType;
	private Map<String, String> listingData;
	

    /**
	 * Creates a listing object and stores the appropriate data in the map.
	 */

	Listing(Map<String, String> listingData, String treeType) {
		this.listingData = listingData;
		id = Integer.parseInt(listingData.get("id"));
		superHost = listingData.get("host_is_superhost").contains("t") ? true : false;
		neighborhood = listingData.get("neighbourhood_cleansed");
		zipcode = listingData.get("zipcode");
		propType = listingData.get("property_type");
		accommodates = validNumber(listingData.get("accommodates"));
		
		bathrooms = validNumber(listingData.get("bathrooms"));
		bathrooms = bathrooms + id/Math.pow(10, String.valueOf(id).length());
		
		bedrooms = validNumber(listingData.get("bedrooms"));
		bedrooms = bedrooms + id/Math.pow(10, String.valueOf(id).length());
		
		dayPrice = validNumber(listingData.get("price"));
		reviewRating = validNumber(listingData.get("review_scores_rating"));
		avail365 = validNumber(listingData.get("availability_365"));
		
		String dub = String.valueOf((365 - avail365) * dayPrice); 
		String dubStr = String.valueOf(dub).substring(0, dub.indexOf(".")) + "."+ String.valueOf(id);
		revenue = new BigDecimal(dubStr);
		
		this.treeType = treeType;

	}
	
    /**
	 * Returns a Listing object based on the input tree type and listing data.
	 * 
	 * @return a Listing object based on the input tree type and listing data6.
	 */
	
	public static Listing changeTreeType(Listing listing, String treeType) {
		return new Listing(listing.getListingData(), treeType);
	}

    /**
	 * Returns a double if the string is represented as a Double, otherwise null.
	 * 
	 * @return a double if the string is represented as a Double, otherwise null.
	 */
	public Double validNumber(String val) {
		if (val.equals("")) {
			return null;
		} else {
			return Double.parseDouble(val);
		}

	}

	String[] header = { "id", "host_is_superhost", "neighbourhood_cleansed", "zipcode", "property_type", "accommodates",
			"bathrooms", "bedrooms", "price", "review_scores_rating", "availability_365" };

    /**
	 * Returns a String array of all the listing items.
	 * 
	 * @return a String array of all the listing items.
	 */
	public String[] toSeq() {
		String[] seq = new String[11];
		seq[0] = (String.valueOf(id));
		seq[1] = (String.valueOf(superHost ? "t" : "f"));
		seq[2] = (neighborhood);
		seq[3] = (zipcode);
		seq[4] = (propType);
		seq[5] = (String.valueOf(accommodates));
		seq[6] = bathrooms == null ? "" : (String.valueOf(bathrooms));
		seq[7] = bedrooms == null ? "" : (String.valueOf(bedrooms));
		seq[8] = (String.valueOf(dayPrice));
		seq[9] = reviewRating == null ? "" : (String.valueOf(reviewRating));
		seq[10] = (String.valueOf(avail365));
		return seq;

	}

    /**
	 * Returns an integer corresponding to the id.
	 * 
	 * @return an integer corresponding to the id.
	 */
	public int getId() {
		return id;
	}

    /**
	 * Returns a boolean value corresponding to whether a host is a superhost (True) or not (False).
	 * 
	 * @return a boolean value corresponding to whether a host is a superhost (True) or not (False).
	 */
	public boolean isSuperHost() {
		return superHost;
	}

    /**
	 * Returns a string corresponding to the neighborhood name.
	 * 
	 * @return a string corresponding to the neighborhood name.
	 */
	public String getNeighborhood() {
		return neighborhood;
	}

    /**
	 * Returns a string corresponding to the zipcode.
	 * 
	 * @return a string corresponding to the zipcode.
	 */
	public String getZipcode() {
		return zipcode;
	}

    /**
	 * Returns a string corresponding to the property type.
	 * 
	 * @return a string corresponding to the property type.
	 */
	public String getPropType() {
		return propType;
	}

    /**
	 * Returns a Double corresponding to the number of accomodations the host can offer.
	 * 
	 * @return a Double corresponding to the number of accomodations the host can offer.
	 */
	public Double getAccommodates() {
		return accommodates;
	}

    /**
	 * Returns a Double corresponding to the number of bathrooms in the property.
	 * 
	 * @return a Double corresponding to the number of bathrooms in the property.
	 */
	public Double getBathrooms() {
		return bathrooms;
	}

    /**
	 * Returns a Double corresponding to the number of bedrooms in the property.
	 * 
	 * @return a Double corresponding to the number of bedrooms in the property.
	 */
	public Double getBedrooms() {
		return bedrooms;
	}

    /**
	 * Returns a Double corresponding to the price of the property per day.
	 * 
	 * @return a Double corresponding to the price of the property per day.
	 */
	public Double getDayPrice() {
		return dayPrice;
	}

    /**
	 * Returns a Double corresponding to the rating of the property.
	 * 
	 * @return a Double corresponding to the rating of the property.
	 */
	public Double getReviewRating() {
		return reviewRating;
	}

    /**
	 * Returns a Double corresponding to the number of days the property is available per year.
	 * 
	 * @return a Double corresponding to the number of days the property is available per year.
	 */
	public Double getAvail365() {
		return avail365;
	}

    /**
	 * Returns a BigDecimal corresponding to the revenue of the property.
	 * 
	 * @return a BigDecimal corresponding to the revenue of the property.
	 */
	public BigDecimal getRevenue() {
		return revenue;
	}
	
    /**
	 * Returns a Map corresponding to the listingData.
	 * 
	 * @return a Map corresponding to the listingData.
	 */
	public Map<String, String> getListingData() {
		return listingData;
	}

    /**
	 * Returns a String when System.out.println() is called.
	 * 
	 * @return a String when System.out.println() is called.
	 */
	@Override
	public String toString() {
		StringBuilder str = new StringBuilder();
		str.append("\n##############################\n");
		str.append("Property Id: " + getId() + "\n");
		str.append("Is Super Host: " + isSuperHost() + "\n");
		str.append("Neighborhood: " + getNeighborhood() + "\n");
		str.append("Zipcode: " + getZipcode() + "\n");
		str.append("Property Type: " + getPropType() + "\n");
		str.append("Accommodates: " +getAccommodates() + "\n");
		str.append("Bathrooms: " + (int)(getBathrooms() - id/Math.pow(10, String.valueOf(id).length())) + " \n");
		str.append("Bedrooms: " +(int)(getBedrooms() - id/Math.pow(10, String.valueOf(id).length())) + "\n");
		str.append("Day Price: " +getDayPrice() + "\n");
		str.append("Review Rating: " +getReviewRating()+ "\n");
		str.append("Revenue: " +getRevenue().intValue() + "\n");
		str.append("\n##############################\n");
		return str.toString();
	}

    /**
	 * Returns an integer when compating listing objects.
	 * 
	 * @return an integer when compating listing objects.
	 */
	@Override
	public int compareTo(Listing obj) {
		Listing that = (Listing) obj;

		if (treeType.equals("revenue")) {
			return compareRev(that);
		} 
		
		if (treeType.equals("bathrooms")) {
			return compareBath(that);
		} 
		
		if (treeType.equals("bedrooms")) {
			return compareBed(that);
		} 
		
		else {
			return 1;
		}

	}


    /**
	 * Returns an integer (1,0,-1)when compating revenue for Listing objects.
	 * 
	 * @return an integer (1,0,-1)when compating revenue for Listing objects.
	 */
	public int compareRev(Listing that) {
//		System.out.println( this.getRevenue() + ">" + that.getRevenue() + " " + this.getRevenue().compareTo(that.getRevenue()) );		
		return this.getRevenue().compareTo(that.getRevenue());

	}
	
    /**
	 * Returns an integer (1,0,-1)when compating bedrooms for Listing objects.
	 * 
	 * @return an integer (1,0,-1)when compating bedrooms for Listing objects.
	 */
	public int compareBed(Listing that) {
		if (this.getId() == that.getId()) {
			return 0;
		} else if (this.getBedrooms() > that.getBedrooms()) {
			return 1;
		} else {
			return -1;
		}
	}
	
    /**
	 * Returns an integer (1,0,-1)when compating bathrooms for Listing objects.
	 * 
	 * @return an integer (1,0,-1)when compating bathrooms for Listing objects.
	 */
	public int compareBath(Listing that) {
		if (this.getId() == that.getId()) {
			return 0;
		} else if (this.getBathrooms() > that.getBathrooms()) {
			return 1;
		} else {
			return -1;
		}
	}

}
