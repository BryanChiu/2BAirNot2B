package XB3;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

/**
 * @author Michael Yohannes
 */


public class NeighborhoodSummary implements Comparable {
	private String neighborhood;
	DescriptiveStatistics neighborhoodData;

	NeighborhoodSummary(String neighborhood, DescriptiveStatistics neighborhoodData) {
		this.neighborhood = neighborhood;
		this.neighborhoodData = neighborhoodData;
	}


    /**
	 * Returns an integer (1, 0, -1) for compating two objects of type NeighborhoodSummary, by their average neighborhood data.
	 * 
	 * @return an integer (1, 0, -1) for compating two objects of type NeighborhoodSummary, by their average neighborhood data.
	 */
	@Override
	public int compareTo(Object obj) {
		NeighborhoodSummary that = (NeighborhoodSummary) obj;
		if (this.neighborhoodData.getMean() > that.neighborhoodData.getMean()) {
			return 1;
		} else if (this.neighborhoodData.getMean() < that.neighborhoodData.getMean()) {
			return -1;
		}
		return 0;
	}

    /**
	 * Returns a String corresponding to the neighboorhood name.
	 * 
	 * @return a String corresponding to the neighboorhood name.
	 */
	public String getNeighborhood() {
		return neighborhood;
	}

    /**
	 * Returns a DescriptiveStatistics object corresponding to the neighboorhood data..
	 * 
	 * @return a DescriptiveStatistics object corresponding to the neighboorhood data.
	 */
	public DescriptiveStatistics getNeighborhoodData() {
		return neighborhoodData;
	}
	
	

}
