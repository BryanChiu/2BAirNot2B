package XB3;

import org.apache.commons.math3.stat.descriptive.DescriptiveStatistics;

/**
 * @author Michael Yohannes
 */
public class ZipCodeSummary implements Comparable {
	private String zipcode;
	DescriptiveStatistics zipcodeData;

    /**
     * @param zipcode corresponding to a String zipcode. 
     * @param zipcodeData is a DescriptiveStats class, and has information about the zipcodeData such as mean and standard deviation. 
     */ 
	ZipCodeSummary(String zipcode, DescriptiveStatistics zipcodeData) {
		this.zipcode = zipcode;
		this.zipcodeData = zipcodeData;
	}

    /**
     * Returns an integer (1, 0, -1) to determine if an object has the same zipcode data by comparing their means.
     * 
     * @param obj is a generic Java object, which is then typecasted to a ZipCodeSummary object.
     * @return an integer (1, 0, -1) to determine if an object has the same zipcode data by comparing their means.
     */
	@Override
	public int compareTo(Object obj) {
		ZipCodeSummary that = (ZipCodeSummary) obj;
		if (this.zipcodeData.getMean() > that.zipcodeData.getMean()) {
			return 1;
		} else if (this.zipcodeData.getMean() < that.zipcodeData.getMean()) {
			return -1;
		}
		return 0;
	}

    /**
     * Returns a String corresponding to the zipcode.
     *
     * @return a String corresponding to the zipcode.
     */
	public String getZipcode() {
		return zipcode;
	}

    /**
     * Returns a DescriptiveStatistics zipcode data.
     *
     * @return a DescriptiveStatistics zipcode data.
     */
	public DescriptiveStatistics getZipcodeData() {
		return zipcodeData;
	}

}
